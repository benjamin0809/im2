import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Events } from 'ionic-angular';


import { JmessageServiceProvider } from '../../../providers/jmessage-service/jmessage-service';
/**
 * Generated class for the ConversationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-conversation',
  templateUrl: 'conversation.html',
})
export class ConversationPage {

  username :string;

  groudId: string;

  messages: any[];

  message: string;

  messagestr: string; 
  constructor(public navCtrl: NavController, 
    public navParams: NavParams,
    public Jmessage: JmessageServiceProvider,
    public events : Events) {

      this.events.subscribe('receive-message',(result)=>{
         this.messages.concat(result);
      })

     
      // alert(this.navParams.data.username)
      this.username = this.navParams.data.username;
      this.getHistory();
  }

  ionViewDidLoad() { 

    
  }
  
  sendMessage(){
   if(!this.message)return; 
    this.Jmessage.sendTextMessageSingle(this.username,this.message).then((msg)=>{
      this.message = '';

      this.getHistory();
    }).catch((error)=>{

    }) 
  }

  getHistory(){
    this.Jmessage.getHistoryMessagesSingleAll(this.username).then((result)=>{
      // alert("result:"+JSON.stringify(result));
      this.messages = result; 
      
    })
  }
  
  doRefresh(refresher) { 

    this.Jmessage.getHistoryMessagesSingleAll(this.username).then((result)=>{
      // alert("result:"+JSON.stringify(result));
      this.messages = result;

      setTimeout(() => {
        console.log('Async operation has ended');
        refresher.complete();
      }, 1000);
    })

   
  }

}
