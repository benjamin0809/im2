# Login

The Login page renders a login form with email/password by default and an optional username field.
